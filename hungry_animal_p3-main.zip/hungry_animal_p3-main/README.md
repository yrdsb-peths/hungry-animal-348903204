# hungry_animal
 
Our hungry elephant tutorial.

A simple game that we are using to help us learn:
- Greenfoot
- Github
- Object-Oriented-Programming.
